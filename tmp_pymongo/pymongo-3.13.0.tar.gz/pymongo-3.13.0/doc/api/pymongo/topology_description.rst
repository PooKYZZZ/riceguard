:orphan:

:mod:`topology_description` -- An object representation of a deployment of MongoDB servers.
===========================================================================================

.. automodule:: pymongo.topology_description

   .. autoclass:: pymongo.topology_description.TopologyDescription()
      :members:

